package com.forum.units;

import java.util.Date;

import com.forum.util.Utility;

public abstract class AbstractEntity {

	private Date created;
	private long id;

	/**
	 *
	 * 
	 *
	 * @return the id of this Abstract entity
	 */
	

	public long getId() {
		return id;
	}

	/**
	 *
	 
	 *
	 * @param id: the id of this Abstract entity
	 */
	
	public void setId(long id) {
		this.id = id;
	}

	/**
	
	 *
	 */
	

	public void autoGenerateId() {
		id = id + 1L;
	}


	public Date getCreated() {
		return created;
	}

	public void setCreated() {
		this.created = Utility.getCurrentDate();
	}
}
